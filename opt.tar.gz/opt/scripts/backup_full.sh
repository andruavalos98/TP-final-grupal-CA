#!/bin/bash
#--- CONFIGURACION DE VARIABLES ---
# Capturamos la fecha actual en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# ---FUNCION DE AYUDA (-help) ---
mostrar_ayuda(){
	echo "Uso $0 [ORIGEN] [DESTINO]"
	echo ""
	echo "Descripcion:"
	echo "	Este script realiza un backup comprimido (.tar.gz) del directorio de origen"
	echo "	y lo almacena en el directorio de destino especificado."
	echo ""
	echo "Argumentos:"
	echo "	ORIGEN	Ruta del directorio al que se le quiere hacer el respaldo (ej: /var/log)."
	echo "	DESTINO	Ruta del directorio donde se guardara el backup (ej: /backup_dir)."
	echo ""
	echo "Opciones:"
	echo "	-help	Muestra este menu de ayuda."
	exit 0
}

# Si el usuario pide ayuda o no pasa argumentos, mostramos la ayuda
if [[ "$1" == "-help"  ]] || [[ -z "$1" ]] || [[ -z "$2" ]]; then
	mostrar_ayuda
fi

# Asignamos los argumento a variables claras
ORIGEN="$1"
DESTINO="$2"

# --- VALIDACIONES ---
# Validar que el directorio de ORIGEN exista y este disponible
if [ ! -d "$ORIGEN" ]; then
	echo "Error: El directorio de origen '$ORIGEN' no esta disponible o no existe."
	exit 1
fi

# Validar que el directorio de DESTINO exista y este disponible 
if [ ! -d "$DESTINO" ]; then
	echo "Error: El directorio de destino '$DESTINO' no esta disponible o no existe (esta montada la particion?)."
	exit 1
fi

# --- EJECUCION DEL BACKUP ---
# Extraemos el nombre de la carpeta de origen para el nombre del archivo (ej: de /var/log toma 'log')
NOMBRE_BASE=$(basename "$ORIGEN")
NOMBRE_ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

echo "Iniciando el respaldo de '$ORIGEN' en '$DESTINO/NOMBRE_ARCHIVO'..."

# Creamos el archivo comprimido .tar.gz
# -z: comprime con gzip, -c: crea nuevo archiv, -f: especifica el nombre del archivo
tar -zcf "$DESTINO/$NOMBRE_ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE"

# Validamos si el comando tar termino con exito
if [ $? -eq 0 ]; then
	echo "Backup completado con exito con formato ANSI!"
else
	echo "Hubo un error al generar el backup"
	exit 1
fi
